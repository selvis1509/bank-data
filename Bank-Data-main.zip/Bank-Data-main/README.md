# Bank-Data
Predicting whether the person will close his bank account or not, using Artificial Neural Networks(ANN).
